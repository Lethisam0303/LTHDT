CREATE TABLE Students (
    StudentID VARCHAR(10) ,
    StudentName VARCHAR(100),
);